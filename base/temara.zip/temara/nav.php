<div class="bouton_menu btn">Menu <i class="icon-chevron-up"></i></div>
<div id="nav">
	<ul>
		<li><a href="./index.php">Nouveautés</a></li>
		<li><a href="./Modules/Recherche/recherche.php">Nos biens</a></li>
		<li><a href="./Modules/Recherche/recherche.php?investisseur=true">Spécial investisseurs</a></li>
		<li><a href="./Modules/Estimation/estimation.php">Estimation et mise en vente</a></li>
		<li><a href="./Modules/Compte/mon_compte.php">Mon compte perso</a></li>
		<li><a href="./Modules/Financement/financement.php">Financement</a></li>
		<li><a href="./Modules/Contact/contact.php">Nous contacter</a></li>
	</ul>
</div>