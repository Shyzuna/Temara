<noscript class="no-print">
	<p class="rouge">Veuillez activer JavaScript pour pouvoir correctement utiliser ce site</p>
</noscript>

<!--[if lte IE 7]>
	<p class="rouge">Votre navigateur est obsolète: veuillez bien vouloir le mettre à jour pour pouvoir utiliser correctement ce site</p>
<![endif]-->